<?php
      session_start();
      if(isset($_SESSION['user'])) {
            $username = $_SESSION['user'][0];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FZONE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/stylemain.css">
</head>
<body>
    <header>
        <div class="color-header container-header">
            <!-- Phần đầu Logo -->
            <div class="logo-section">
                <a href=""><img src="assets/img/Logo2024black.png" alt=""></a>
            </div>
            <!-- Phần Kết Logo -->
            <div class="zindex  input-section">
                <!-- Phần đầu input -->
                <div class="search-section">
                    <form action="" method="post">
                        <input type="search" placeholder="Tìm kiếm" name="q" class="search-input">
                        <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </form>
                </div>
                 <!-- Phần kết input -->
            </div>
            <!-- Phần thông tin hỗ trợ, đăng nhập -->
            <div class="color-header search-information">
                <div class="color-header navbar">
                    <ul class="nav-list">
                        <li class="nav-item">
                            <a href="#">
                                <i class="fas fa-bell"></i>Thông tin
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#">
                                <i class="fas fa-question-circle"></i>Hỗ trợ
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="cart.php">
                                <i class="fas fa-shopping-cart"></i>Giỏ hàng
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="dangnhap.php">
                                <i class="fa-solid fa-user"></i> Đăng Nhập
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Phần kết thông tin hỗ trợ, đăng nhập -->
        </div>
    </header>
    <nav>
        <!-- Thông tin dịch vụ -->
        <div class="service-list">
            <div class="account">
                <span>Welcome, <?php echo $username; ?>!</span>
                <i class="fa-solid fa-right-from-bracket"></i><a href="logout.php">Logout</a>
            </div>
            <div class="navbar1">
                <ul class="nav-list1">
                    <li class="nav-item1">
                        <a href="#"> Ưu đãi hôm nay</a>
                    </li>
                    <li class="nav-item1">
                        <a href="#">Dịch vụ khách hàng</a>
                    </li>
                    <li class="nav-item1">
                        <a href="#">Thẻ quà tặng</a>
                    </li>
                    <li class="nav-item1">
                        <a href="#">Kênh người bán</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- kết Thông tin dịch vụ -->
    </nav>
        <!--Phần hình nền-->
    <div class="slider">
        <img src="assets/img/background.jpg" alt="">
    </div>
        <!--Phần kết hình nền-->
    <article>
        <!--Phần sản phẩm-->
        <div class="container-product">
            <div class="box-product1">
                <div class="title1">
                    Phụ Kiện Chơi Game
                </div>
                <div class="detail-box-product1">
                    <div class="box1">
                        <a href="product-phone1.html"><img src="assets/img/tainghe.jpg" alt=""></a>
                        <div class="name1"><p>Tai nghe</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/banphim.jpg" alt=""></a>
                        <div class="name1"><p>Bàn phím</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/chuot.jpg" alt=""></a>
                        <div class="name1"><p>Chuột</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/ghe.jpg" alt=""></a>
                        <div class="name1"><p>Ghế</p></div>
                    </div>
                    <div class="more-content">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Ưu Đãi PC
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/PC.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Tạo Ra Giải Pháp Kinh Doanh
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/taoragiaiphapkinhdoanh.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Laptop Cho Mọi Nhu Cầu
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/laptopchomoinhucau.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Làm Đẹp Không Gian Của Bạn
                </div>
                <div class="detail-box-product1">
                    <div class="box1">
                        <a href=""><img src="assets/img/dungcuanuong.jpg" alt=""></a>
                        <div class="name1"><p>Dụng cụ ăn uống</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/vatlieutrangtrinha.jpg" alt=""></a>
                        <div class="name1"><p>Trang trí nhà</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/phongbep.jpg" alt=""></a>
                        <div class="name1"><p>Phòng bếp</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/suckhoevasacdep.jpg" alt=""></a>
                        <div class="name1"><p>Mỹ phẩm</p></div>
                    </div>
                    <div class="more-content">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Qùa Tặng Hấp Dẫn
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/quatanghapdan.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Mua Sắm Thời Trang
                </div>
                <div class="detail-box-product1">
                    <div class="box1">
                        <a href=""><img src="assets/img/tainghe.jpg" alt=""></a>
                        <div class="name1"><p>Quần Jean</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/banphim.jpg" alt=""></a>
                        <div class="name1"><p>Áo thun</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/chuot.jpg" alt=""></a>
                        <div class="name1"><p>Váy</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/ghe.jpg" alt=""></a>
                        <div class="name1"><p>Giày</p></div>
                    </div>
                    <div class="more-content">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Ưu Đãi về Giày
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/uudaivegiay.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Nâng Cấp Thói Quen Làm Đẹp
                </div>
                <div class="detail-box-product1">
                    <div class="box1">
                        <a href=""><img src="assets/img/trangdiem.jpg" alt=""></a>
                        <div class="name1"><p>Trang điểm</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/buttrangdiem.jpg" alt=""></a>
                        <div class="name1"><p>Bút trang điểm</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/botbien.jpg" alt=""></a>
                        <div class="name1"><p>Bọt biển</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/botbienguong.jpg" alt=""></a>
                        <div class="name1"><p>Bọt biển gương</p></div>
                    </div>
                    <div class="more-content">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Tăng Cấp Cho Chơi Của Bạn
                </div>
                <div class="detail-box-product1">
                    <div class="box1">
                        <a href=""><img src="assets/img/choigametrenPC.jpg" alt=""></a>
                        <div class="name1"><p>Chơi Game Trên PC</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/xbox.jpg" alt=""></a>
                        <div class="name1"><p>Xbox</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/playstation.jpg" alt=""></a>
                        <div class="name1"><p>PlayStation</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/nintendo.jpg" alt=""></a>
                        <div class="name1"><p>Nintendo Switch</p></div>
                    </div>
                    <div class="more-content">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Hàng Hóa Trò Chơi
                </div>
                <div class="detail-box-product1">
                    <div class="box1">
                        <a href=""><img src="assets/img/trangphuc.jpg" alt=""></a>
                        <div class="name1"><p>Trang phục</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/non.jpg" alt=""></a>
                        <div class="name1"><p>Nón</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/nhanvat.jpg" alt=""></a>
                        <div class="name1"><p>Nhân vật hành động</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/coc.jpg" alt=""></a>
                        <div class="name1"><p>Cốc</p></div>
                    </div>
                    <div class="more-content">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Ưu Đãi Qùa Tặng Cho Bố
                </div>
                <div class="detail-box-product1">
                    <div class="box1">
                        <a href=""><img src="assets/img/congnghe.jpg" alt=""></a>
                        <div class="name1"><p>Công nghệ</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/thietbiphieuluu.jpg" alt=""></a>
                        <div class="name1"><p>Thiết bị phiên lưu</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/banco.jpg" alt=""></a>
                        <div class="name1"><p>Bàn cờ</p></div>
                    </div>
                    <div class="box1">
                        <a href=""><img src="assets/img/dungcutapta.jpg" alt=""></a>
                        <div class="name1"><p>Dụng cụ tập tạ</p></div>
                    </div>
                    <div class="more-content">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Thiên Đường Trò Chơi
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/thienduong.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Đồ Dưới 500k
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/doduoi500l.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Laptop Cho Mọi Nhu Cầu
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/laptopchomoinhucau.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product1">
                <div class="title1">
                    Laptop Cho Mọi Nhu Cầu
                </div>
                <div class="detail-box-product2">
                    <div class="box2">
                        <a href=""><img src="assets/img/laptopchomoinhucau.jpg" alt=""></a>
                    </div>
                    <div class="more-content1">
                        <a href=""><p>Xem thêm</p></a>
                    </div>
                </div>
            </div>
            <div class="box-product3">
                <div class="title1">
                    Most wished for in Movies & TV
                </div>
                <div class="detail-box-product3">
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="box-product3">
                <div class="title1">
                    Most wished for in Movies & TV
                </div>
                <div class="detail-box-product3">
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                    <div class="box3">
                        <a href="#"><img src="assets/img/phim1.jpg" alt=""></a>
                    </div>
                </div>
            </div>
            
        </div>
    </article>
    <footer>
        <div class="box-footer">
            <div class="ft">
                <h3>Về FZONE</h3>
                <a href=""><p>Giới thiệu</p></a>
                <a href=""><p>Tuyển dụng</p></a>
                <br><br>
            </div>
            <div class="ft">
                <h3>Chính sách</h3>
                <a href=""><p>Chính sách bảo hành</p></a>
                <a href=""><p>Chính sách thanh toán</p></a>
                <a href=""><p>Chính sách giao hàng</p></a>
                <a href=""><p>Chính sách bảo mật</p></a>
            </div>
            <div class="ft">
                <h3>Thông tin</h3>
                <a href=""><p>Hệ thống cửa hàng</p></a>
                <a href=""><p>Hướng dẫn mua hàng</p></a>
                <a href=""><p>Tra cứu địa chỉ bảo hành</p></a>
                <br>
            </div>
            <div class="ft">
                <h3>Liên hệ với chúng tôi</h3>
                <a href=""><p>Mua hàng: 0815934934</p></a>
                <a href=""><p>Bảo hành: 1800.6173</p></a>
                <a href=""><p>Email: lukiluna23803@gmail.com</p></a>
                <br>
            </div>
            <div class="ft">
                <h3>Kết nối với chúng tôi</h3>
                <a  href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook"></i></a>
                <a  href="https://www.youtube.com" target="_blank"><i class="fab fa-youtube"></i></a>
                <br><br><br><br><br>
            </div>
    </footer>
</body>
</html>
<?php
      }
      else {
            echo 'Please log in again. <a href="index.php">Click here</a>';
      }
?>