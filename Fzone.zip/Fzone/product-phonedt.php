<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FZONE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="icon" type="image/x-icon" href="assets/img/favicon.ico">
    <link rel="stylesheet" href="assets/css/styledt.css">
    <link rel='stylesheet prefetch' href='https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css'>
</head>
<body>
    <header>
        <div class="color-header container-header">
            <!-- Phần đầu Logo -->
            <div class="logo-section">
                <a href="index.php"><img src="assets/img/Logo2024black.png" alt=""></a>
            </div>
            <!-- Phần Kết Logo -->
            <div class="zindex  input-section">
                <!-- Phần đầu input -->
                <div class="search-section">
                    <form action="" method="post">
                        <input type="search" placeholder="Tìm kiếm" name="q" class="search-input">
                        <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </form>
                </div>
                 <!-- Phần kết input -->
            </div>
            <!-- Phần thông tin hỗ trợ, đăng nhập -->
            <div class="color-header search-information">
                <div class="color-header navbar">
                    <ul class="nav-list">
                        <li class="nav-item">
                            <a href="#">
                                <i class="fas fa-bell"></i>Thông tin
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#">
                                <i class="fas fa-question-circle"></i>Hỗ trợ
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="cart.php">
                                <i class="fas fa-shopping-cart"></i>Giỏ hàng
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="dangnhap.html">
                                <i class="fas fa-sign-in-alt"></i> Đăng Nhập
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- Phần kết thông tin hỗ trợ, đăng nhập -->
        </div>
    </header>
    <nav>
        <div class="service-list">
            <div class="navbar1">
                <ul class="nav-list1">
                    <li class="nav-item1">
                        <a href="#"> Ưu đãi hôm nay</a>
                    </li>
                    <li class="nav-item1">
                        <a href="#">Dịch vụ khách hàng</a>
                    </li>
                    <li class="nav-item1">
                        <a href="#">Thẻ quà tặng</a>
                    </li>
                    <li class="nav-item1">
                        <a href="#">Kênh người bán</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <article>
        <div class="container-product">
            <div class="box-product1">
                    <!-- Phần chính -->
                <form action="addcart.php" method="post">
                    <div class="detail-box-product">
                        <div class="box5">
                            <a href=""><img src="assets/img/tainghe1.webp" alt=""></a>
                        </div>
                        <div class="information-sp">
                            <div class="name"><h3>BENGOO G9000</h3></div>
                                <div class="pricedt">
                                    1490000₫<del>2490000₫</del>
                                </div>
                                <div class="buy">
                                    <input type="submit" value="MUA NGAY" name="addcart"><br><i>Giao tận nơi hoặc nhận tại cửa hàng</i>
                                </div>
                        <p class="sl">
                            Số lượng
                            <input type="number" name="count" min="1" max="10" value="1">
                        </p> 
                         <input type="hidden" name="img" value="tainghe1.webp">
                         <input type="hidden" name="name" value="BENGOO G9000">
                         <input type="hidden" name="price" value="1490000">
                         <input type="hidden" name="id" value="001">
                </form>
                    <!-- Phần chính -->
                        <div class="feedback"><a href="">Xem đánh giá</a></div>
                        <div class="stars">
                            <form action="">
                              <input class="star star-5" id="star-5" type="radio" name="star"/>
                              <label class="star star-5" for="star-5"></label>
                              <input class="star star-4" id="star-4" type="radio" name="star"/>
                              <label class="star star-4" for="star-4"></label>
                              <input class="star star-3" id="star-3" type="radio" name="star"/>
                              <label class="star star-3" for="star-3"></label>
                              <input class="star star-2" id="star-2" type="radio" name="star"/>
                              <label class="star star-2" for="star-2"></label>
                              <input class="star star-1" id="star-1" type="radio" name="star"/>
                              <label class="star star-1" for="star-1"></label>
                            </form>
                        </div>
                        <div class="thongtin">
                            <p><b>Thương hiệu:</b>BENGOO</p>
                            <p><b>Tên mẫu:</b>G9000</p>
                            <p><b>Màu:</b>xanh</p>
                            <p><b>Yếu tố hình thức:</b> qua tai</p>
                            <p><b>Công nghệ kết nối:</b> có dây</p>
                        </div>
                    </div>
                    <div class="thongso">
                        <div class="bangthongso">
                            <h1>THÔNG SỐ KĨ THUẬT :</h1>
                            <table>
                                <tr>
                                    <td class="highlight">Thương hiệu</td>
                                    <td>BENGOO</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Tên sản phẩm</td>
                                    <td>Tai nghe Corsair Virtuoso RGB Wireless Pearl</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Model</td>
                                    <td>Virtuoso Wireless</td>
                                </tr>
                                <tr>
                                    <td class="highlight" colspan="2">THÔNG SỐ TAI NGHE</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Loại tai nghe</td>
                                    <td> Wireless</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Chất liệu</td>
                                    <td>Khung kim loại, đệm tai xốp Foam</td>
                                </tr>
                                <tr>
                                    <td colspan="2">Màu sắc	Ngọc trai (Pearl)</td>
                                </tr>
                                <tr>
                                    <td class="highlight">LED</td>
                                    <td>RGB</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Kết nối</td>
                                    <td>Wireless</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Chất lượng âm thanh</td>
                                    <td>7.1 Surround</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Âm thanh vòm</td>
                                    <td>Yes</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Kích thước màng loa</td>
                                    <td>50 mm</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Kết nối</td>
                                    <td>Wireless</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Tần số đáp ứng</td>
                                    <td>20Hz - 40kHz</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Trở kháng</td>
                                    <td>32 Ohms @ 2.5 kHz</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Độ nhạy tai nghe</td>
                                    <td>109dB (+/-3dB)</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Tương thích</td>
                                    <td>Wireless</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Kết nối</td>
                                    <td>PC, PS5, PS4</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Phần mềm</td>
                                    <td>Audio CUE</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Kích thước (mm)</td>
                                    <td>160 x 100 x 205</td>
                                </tr>
                                <tr>
                                    <td class="highlight" colspan="2">THÔNG SỐ MICROPHONE</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Kết nối</td>
                                    <td>Rời</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Tần số đáp ứng</td>
                                    <td>100Hz đến 10kHz</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Độ nhạy	-40dB</td>
                                    <td>(+/-3dB)</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Trở kháng</td>
                                    <td>2.0k Ohms</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Khử tiếng ồn</td>
                                    <td>Có</td>
                                </tr>
                                <tr>
                                    <td class="highlight">Khác</td>
                                    <td>Sách HDSD</td>
                                </tr>
    
                            </table>
                        </div>
                    </div>
                    <div class="thongtinsanpham">
                        <div class="bangthongtin">
                            <h2>THÔNG TIN SẢN PHẨM:</h2>
                            <p>
                            Đánh giá chi tiết tai nghe Corsair Virtuoso RGB Wireless Pearl
                            Tai nghe Corsair Virtuoso RGB Wireless Pearl là chiếc tai nghe mới nhất của Corsair, đây chắc chắn là một trong những chiếc tai nghe không dây High-End mới nhất cho tới thời điểm hiện tại sở hữu tất cả những điểm mạnh nhất từ nhà Corsair: từ chất lượng thiết kế, âm thanh, thiết kế đều mang nét đột phá cao cấp.                      
                            </p>
                            <h2>Thiết kế cao cấp đi cùng sự hoàn hảo</h2>
                            <p>
                            Tai nghe Corsair Virtuoso RGB Wireless Pearl khoác lên gam màu Pearl sang trọng đi cùng cấu trúc hoàn hảo gia công từ nhôm đem lại sự thoải mái, gọn nhẹ cho chiếc tai nghe. 
                            Chất lượng âm thanh tuyệt đỉnh
                            Tai nghe Corsair Virtuoso RGB Wireless Pearl được trang bị bộ driver neodymium 50mm với mật độ cùng dải tần số  20Hz - 40kHz cho bạn cảm nhận âm thanh từ bé nhất như tiếng bước chân trong các tựa game FPS đến âm bass, treble của những bản nhạc.
                            </p>
                            <h2>Thiết kế cao cấp đi cùng sự hoàn hảo</h2>
                            <p>
                            Miếng đệm tai của tai nghe Corsair Virtuoso RGB Wireless Pearl được làm từ xốp cao cấp cùng với phần headband siêu nhẹ cho người dùng thoải mái ngay cả khi phải sử dụng tai nghe trong thời gian dài, đem lại cảm giác như tựa đầu lên chiếc gối mềm mại.
                            Phần micro của tai nghe Corsair Virtuoso RGB Wireless Pearl có thể tháo rời, giúp bạn thoải mái gắn hoặc tháo ra khi không sử dụng, đem lại sự gọn gàng hơn những chiếc tai nghe wireless.
                            </p>
                            <h2>Kết nối của tai nghe Corsair Virtuoso RGB Wireless Pearl</h2>
                            <p>
                            Đối với tai nghe Corsair Virtuoso RGB Wireless Pearl thì việc kết nối không phải là điều bận tâm ở đây, “nhạc nào cũng nhảy”. Corsair đem đến cho đứa con của mình cả 3 kiểu kết nối với: Kết nối USB mang đến chất lượng trung thực nhất, kết nối 3.5mm cho phép chiếc tai nghe có thể kết nối dễ dàng với các thiết bị di động và cuối cùng đó là công nghệ Slipstream Wireless giúp cho việc kết nối không dây với khoảng cách lên tới 60ft vẫn đem lại chất lượng tuyệt vời nhất.
                            Ngoài ra công nghệ Slipstream của Corsair còn giúp cho việc thu âm tốt hơn bao giờ hết cho giọng nói của bạn truyền đi được chính xác và tự nhiên hơn trong cuộc gọi trực tuyến hoặc trong trò chơi.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </article>
    <footer>
        <div class="box-footer">
            <div class="ft">
                <h3>Về FZONE</h3>
                <a href=""><p>Giới thiệu</p></a>
                <a href=""><p>Tuyển dụng</p></a>
                <br><br>
            </div>
            <div class="ft">
                <h3>Chính sách</h3>
                <a href=""><p>Chính sách bảo hành</p></a>
                <a href=""><p>Chính sách thanh toán</p></a>
                <a href=""><p>Chính sách giao hàng</p></a>
                <a href=""><p>Chính sách bảo mật</p></a>
            </div>
            <div class="ft">
                <h3>Thông tin</h3>
                <a href=""><p>Hệ thống cửa hàng</p></a>
                <a href=""><p>Hướng dẫn mua hàng</p></a>
                <a href=""><p>Tra cứu địa chỉ bảo hành</p></a>
                <br>
            </div>
            <div class="ft">
                <h3>Liên hệ với chúng tôi</h3>
                <a href=""><p>Mua hàng: 0815934934</p></a>
                <a href=""><p>Bảo hành: 1800.6173</p></a>
                <a href=""><p>Email: lukiluna23803@gmail.com</p></a>
                <br>
            </div>
            <div class="ft">
                <h3>Kết nối với chúng tôi</h3>
                <a  href="https://www.facebook.com" target="_blank"><i class="fab fa-facebook"></i></a>
                <a  href="https://www.youtube.com" target="_blank"><i class="fab fa-youtube"></i></a>
                <br><br><br><br><br>
            </div>
    </footer>
</body>
</html>